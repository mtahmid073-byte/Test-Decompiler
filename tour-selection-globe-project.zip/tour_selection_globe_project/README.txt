Tour Selection Globe Test

This rebuild is intentionally only a standalone UI screen. It uses assets from the uploaded Nautilus Cricket package:
- assets/AllScreens/tourmode/map.png
- assets/AllScreens/tourmode/worldmap.png
- country highlight PNGs
- Common left/right arrow assets

Country overlay positions were copied from the decompressed TourSelection_1280x720.csb data.
No custom theme and no match engine is embedded. NEXT only writes a small tourSelectionState object to localStorage.

Controls:
- left/right arrows: change tour country
- click country: select tour country
- swipe: change tour country
- D: debug panel
- H: show hidden CSB difficulty label
- M: cycle difficulty
